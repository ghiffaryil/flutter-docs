# Contribution Guidelines

In order to contribute to this repository you need to **fork** it, then you can create a pull request.

Each pull request need to be reviewed before merged, if any of the modification impact on the structure or produce breaking changes update documentation too.

If you want to support and update readme (e.g. list of supported tag), same rule as above applies!

Thank you for contribution.
