package it.matteocrippa.flutternfcreader

const val kId = "nfcId"
const val kContent = "nfcContent"
const val kError = "nfcError"
const val kStatus = "nfcStatus"
