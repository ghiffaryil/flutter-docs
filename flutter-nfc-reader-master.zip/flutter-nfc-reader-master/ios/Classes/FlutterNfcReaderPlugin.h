#import <Flutter/Flutter.h>

@interface FlutterNfcReaderPlugin : NSObject<FlutterPlugin>
@end
