# Changelog

## 0.2.0
Improved android support

## 0.1.1
Add support for swift continuous reading
Improved documentation

## 0.1.0

* Total refactor, add write support for Android

## 0.0.23

* Improved Android support.

## 0.0.14

* Stable iOS version.
* Fix issue with importing with Cocoapods.

## 0.0.5

* iOS fix support for static modules.

## 0.0.4

* iOS add extra details on readme for usage.

## 0.0.3

* Flutter required min version is now 0.5.5 as latest stable.

## 0.0.2

* Name refactoring for functions, more descriptive and synteic.
* On read event force stopping the pooling in background to optimize usage.

## 0.0.1

* First release, android untested.
